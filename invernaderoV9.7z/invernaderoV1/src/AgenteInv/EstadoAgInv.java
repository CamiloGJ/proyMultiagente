/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AgenteInv;

import BESA.Kernel.Agent.AgentBESA;
import BESA.Kernel.Agent.KernelAgentExceptionBESA;
import BESA.Kernel.Agent.StateBESA;
import BESA.Kernel.Agent.StructBESA;
import java.util.ArrayList;

public class EstadoAgInv extends StateBESA{
    private int temperature;
    private int humidity;
    
    public final int T_MIN = 25;
    public final int T_MAX = 33;
    
    public final int H_MIN = 71;
    public final int H_MAX = 77;
    
    public final int T_OFFST = 5;
    public final int H_OFFST = 2;
    
    public int Toffst;
    public int Hoffst;
    /**
     * Initializes the state.
     * 
     * @param profile Startup parameters.
     */
    public synchronized void initState(ArrayList profile) {
    }
    
    public EstadoAgInv(){
        super();
    }
    
    /**
    * Gets the temperature.
    * @return Counter.
    */
    public int getTemperature() {
        return temperature;
    }

    /**
     * Sets the temperature.
     * 
     * @param temp temperature.
     */
    public void setTemperature(int temp) {
        this.temperature = temp;
    }
    
    /**
    * Gets the temperature.
    * @return Counter.
    */
    public int getHumidity() {
        return humidity;
    }

    /**
     * Sets the temperature.
     * 
     * @param humdt temperature.
     */
    public void setHumidity(int hmdt) {
        this.humidity = hmdt;
    }
    
    public void adjustTemperature(int temp){
        if(temp <= T_MAX && temp >= T_MIN){
            this.Toffst = 0;
        }else if(temp < T_MIN){
            this.Toffst = T_OFFST;
        }else{
            this.Toffst = (-1)*T_OFFST;
        }
    }
    
    public void adjustHumidity(int hmdt){
        if(hmdt <= H_MAX && hmdt >= H_MIN){
            this.Hoffst = 0;
        }else if(hmdt < H_MIN){
            this.Hoffst = H_OFFST;
        }else{
            this.Hoffst = (-1)*H_OFFST;
        }
    }
}
