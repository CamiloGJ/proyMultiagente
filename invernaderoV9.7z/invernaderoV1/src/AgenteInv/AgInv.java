/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AgenteInv;

import AgenteEnv.EstadoAgEnv;
import AgenteEnv.Tcounter;
import BESA.Kernel.Agent.AgentBESA;
import BESA.Kernel.Agent.KernelAgentExceptionBESA;
import BESA.Kernel.Agent.StateBESA;
import BESA.Kernel.Agent.StructBESA;
import java.util.ArrayList;

/**
 *
 * @author camil
 */
public class AgInv extends AgentBESA {
    private int INIT_HMDT;
    private int INIT_TEMP;

    public AgInv(String alias, StateBESA state, StructBESA structAgent, double passwd) throws KernelAgentExceptionBESA {
        super(alias, state, structAgent, passwd);
        this.INIT_HMDT = 75;
        this.INIT_TEMP = 30;
    }
    
    @Override
    public void setupAgent() {
        //iniciaizar la matriz 4*4 de plantas
        // cada celda de la matriz tiene unas variables asociadas planta, plaga, nutrientes
        // el ambiente tiene tambien unas variables asociadas que se modelan matematicamente
        // llame esos metodos de estado
        EstadoAgInv stateInv = (EstadoAgInv) this.state;
        stateInv.setHumidity(INIT_HMDT);           
        stateInv.setTemperature(INIT_TEMP);
        ArrayList<Integer> v = new ArrayList<>();                               //Sets the initial state.
        v.add(1);
        stateInv.initState(v);
    }

    @Override
    public void shutdownAgent() {
    }   
}
